# Buzz! Web Lite — PWA V2 (iPhone/iPad)

## Triển khai qua GitHub Actions + GitHub Pages

1. Tạo repo mới `buzz-web-lite-ios` trên GitHub, chọn **Public**, nhánh `main`.
2. Giải nén ZIP này. Upload **các file và thư mục ở bên trong** lên gốc repo: `index.html`, `manifest.webmanifest`, `sw.js`, `.nojekyll`, thư mục `icons/`. KHÔNG upload chỉ file .zip và đừng đặt tất cả trong một thư mục con.
3. Vào **Settings > Pages > Build and deployment > Source > GitHub Actions**.
4. Vào **Add file > Create new file** đặt tên `.github/workflows/pages.yml`. Dán workflow YAML trong hướng dẫn ChatGPT.
5. Commit. Vào **Actions** để xem workflow chạy. Sau khi xanh, xem **Settings > Pages** để lấy URL.
6. Safari iPhone mở URL > Share > Add to Home Screen > mở icon Buzz! Lite.

## Chức năng

- Dùng chung Supabase Buzz! qua publishable key (không chứa service_role/YouTube API key).
- Đăng nhập hiện có, Buddy List, Chat 1-1 chữ, Room chữ, YouTube Video/Playlist và thư viện kênh YouTube.
- PWA manifest, icon Buzz gốc, Service Worker cache **tài nguyên giao diện tĩnh** để cài lên iPhone.
- Chưa cài Push Subscription (VAPID) và máy chủ Supabase gửi Web Push; `sw.js` chỉ sẵn sàng xử lý nếu có push về sau. **Chưa có thông báo đẩy khi khóa màn hình**.
- Chưa hỗ trợ cuộc gọi Voice/Video, thông báo cuộc gọi đến kiểu native, Story/Post/Drive.
- Có thể cần đăng nhập lại sau khi đóng ứng dụng PWA vì phiên chỉ giữ trong RAM; không lưu token vào localStorage.
- Nếu mất mạng, giao diện có thể mở từ cache nhưng KHÔNG tải được dữ liệu Supabase hay phát YouTube.
- PWA cài từ GitHub Pages KHÔNG phải IPA/TestFlight/App Store.

## Bảo mật

Repo GitHub Pages là trang công khai. Không push `.env`, password, VAPID private key, API key YouTube hay `service_role`.
`sb_publishable_...` là khóa dành cho client công khai, vẫn phải bảo vệ database với RLS và RPC quyền thích hợp.
Chỉ mở rộng tester sau khi test đăng nhập, quyền truy cập, và các tin nhắn bằng hai tài khoản thử.

## Cập nhật

Sửa / upload lại file trong repo > commit > GitHub Actions tự triển khai; người dùng iPhone có thể đóng và mở PWA để tải bản mới.
