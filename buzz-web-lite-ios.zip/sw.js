/* Buzz! Web Lite PWA V2 — offline shell only. Does NOT cache API calls or conversations. */
'use strict';
const CACHE = 'buzz-lite-pwa-v2-shell-20261017';
const ASSETS = ['./','./index.html','./manifest.webmanifest',
                './icons/icon-192.png','./icons/icon-512.png','./icons/apple-touch-icon.png'];
self.addEventListener('install', event => {
  event.waitUntil(caches.open(CACHE).then(cache=>cache.addAll(ASSETS)).then(()=>self.skipWaiting()));
});
self.addEventListener('activate', event=>{
  event.waitUntil(Promise.all([
    caches.keys().then(keys=>Promise.all(keys.filter(k=>k.startsWith('buzz-lite-pwa-')&&k!==CACHE).map(k=>caches.delete(k)))),
    self.clients.claim()
  ]));
});
self.addEventListener('fetch', event=>{
  const req=event.request;
  if(req.method!=='GET') return;
  const url=new URL(req.url);
  if(url.origin!==self.location.origin) return; // never intercept YouTube or Supabase
  if(req.mode==='navigate') {
    event.respondWith(fetch(req).catch(()=>caches.match('./index.html')));
    return;
  }
  const assets=['/index.html','/manifest.webmanifest','/icons/icon-192.png','/icons/icon-512.png','/icons/apple-touch-icon.png'];
  if(assets.some(x=>url.pathname.endsWith(x))) {
    event.respondWith(caches.match(req).then(cached=>cached||fetch(req)));
  }
});
// Receives Web Push only AFTER the separate Supabase push subscription + sender are configured.
self.addEventListener('push', event=>{
  let payload={};
  try { payload=event.data?.json()||{}; } catch { payload={body:event.data?.text()||''}; }
  const title=String(payload.title||'Buzz! Messenger').slice(0,100);
  const target=new URL(String(payload.url||'./'),self.registration.scope);
  const safeUrl=target.href.startsWith(self.registration.scope)?target.href:self.registration.scope;
  event.waitUntil(self.registration.showNotification(title,{
    body:String(payload.body||'Có cập nhật mới trong Buzz!').slice(0,180),
    icon:'./icons/icon-192.png',badge:'./icons/icon-192.png',
    tag:String(payload.tag||'buzz-message').slice(0,80),
    data:{url:safeUrl}
  }));
});
self.addEventListener('notificationclick',event=>{
  event.notification.close();
  const u=event.notification.data?.url||self.registration.scope;
  event.waitUntil(self.clients.matchAll({type:'window',includeUncontrolled:true}).then(list=>{
    const found=list.find(c=>c.url.startsWith(self.registration.scope));
    return found?(found.focus()):self.clients.openWindow(u);
  }));
});
